package InsertionSort;

public class Construtor {
	@SuppressWarnings("unused")
	 public static void main(String[] args) {
        // Definindo o tamanho da estrutura
        int quantidade = 10;
        // Criando a estrutura
        int[] vetor = {30, 20, 10, 40, 50, 90, 80, 70, 60, 100};
        
        // Ordenando o vetor usando o modelo
        Modelo.insertionSort(vetor);
        // Ou usando o bubble sort
        // Modelo.bubbleSort(vetor);
        
        // Mostrando o vetor ordenado usando a visão
        Visao.mostrarVetorOrdenado(vetor);
    }
}
