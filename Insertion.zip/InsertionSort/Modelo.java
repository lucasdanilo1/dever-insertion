package InsertionSort;

public class Modelo {
	
	 public static void insertionSort(int[] vetor) {
	        for (int j = 1; j < vetor.length; j++) {
	            int key = vetor[j];
	            int i = j - 1;
	            while (i >= 0 && vetor[i] > key) {
	                vetor[i + 1] = vetor[i];
	                i--;
	            }
	            vetor[i + 1] = key;
	        }
	    }
	    
	    public static void bubbleSort(int[] vetor) {
	        int n = vetor.length;
	        for (int i = 0; i < n-1; i++) {
	            for (int j = 0; j < n-i-1; j++) {
	                if (vetor[j] > vetor[j+1]) {
	                    // troca vetor[j] com vetor[j+1]
	                    int temp = vetor[j];
	                    vetor[j] = vetor[j+1];
	                    vetor[j+1] = temp;
	                }
	            }
	        }
	    }	}
	

	
