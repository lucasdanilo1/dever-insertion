package InsertionSort;

public class Visao {
	
	public static void mostrarVetorOrdenado(int[] vetor) {
        System.out.println("Vetor Ordenado:");
        for (int k = 0; k < vetor.length; k++) {
            System.out.println(vetor[k]);
        }
    }
}
